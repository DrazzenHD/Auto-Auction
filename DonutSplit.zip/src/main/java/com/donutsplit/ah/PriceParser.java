package com.donutsplit.ah;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.OptionalLong;

/** Parses prices such as "2500", "1,500", "10k", "2.5m", "1b" into a whole number. */
public final class PriceParser {

    private PriceParser() {
    }

    public static OptionalLong parse(String raw) {
        if (raw == null) {
            return OptionalLong.empty();
        }
        String s = raw.trim().toLowerCase(Locale.ROOT).replace(",", "").replace("_", "").replace("$", "");
        if (s.isEmpty()) {
            return OptionalLong.empty();
        }

        long multiplier = 1L;
        char last = s.charAt(s.length() - 1);
        boolean hasSuffix = true;
        switch (last) {
            case 'k' -> multiplier = 1_000L;
            case 'm' -> multiplier = 1_000_000L;
            case 'b' -> multiplier = 1_000_000_000L;
            case 't' -> multiplier = 1_000_000_000_000L;
            default -> hasSuffix = false;
        }
        if (hasSuffix) {
            s = s.substring(0, s.length() - 1);
        }

        try {
            BigDecimal value = new BigDecimal(s).multiply(BigDecimal.valueOf(multiplier)).stripTrailingZeros();
            if (value.signum() <= 0 || value.scale() > 0) {
                return OptionalLong.empty();
            }
            return OptionalLong.of(value.longValueExact());
        } catch (NumberFormatException | ArithmeticException e) {
            return OptionalLong.empty();
        }
    }
}
