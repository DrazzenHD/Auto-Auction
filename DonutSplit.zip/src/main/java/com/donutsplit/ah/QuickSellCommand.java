package com.donutsplit.ah;

import com.donutsplit.DonutSplitClient;
import com.donutsplit.config.ModConfig;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

import java.util.OptionalLong;

/**
 * Client-side helper command:
 *   /quicksell          opens the quick-sell screen
 *   /quicksell 10k      sends "/ah sell 10000" for the item in your hand
 * It does not replace or intercept the server's own /ah command.
 */
public final class QuickSellCommand {

    private QuickSellCommand() {
    }

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("quicksell")
                        .executes(ctx -> {
                            DonutSplitClient.requestOpenAh();
                            return 1;
                        })
                        .then(ClientCommandManager.argument("price", StringArgumentType.word())
                                .executes(ctx -> {
                                    String raw = StringArgumentType.getString(ctx, "price");
                                    ModConfig cfg = ModConfig.get();
                                    Minecraft mc = Minecraft.getInstance();
                                    LocalPlayer player = mc.player;
                                    if (player == null) {
                                        return 0;
                                    }
                                    if (!cfg.ahEnabled) {
                                        ctx.getSource().sendFeedback(Component.translatable("donutsplit.ah.disabled"));
                                        return 0;
                                    }
                                    if (player.getMainHandItem().isEmpty()) {
                                        ctx.getSource().sendFeedback(Component.translatable("donutsplit.ah.hold_item"));
                                        return 0;
                                    }
                                    OptionalLong price = PriceParser.parse(raw);
                                    if (price.isEmpty()) {
                                        ctx.getSource().sendFeedback(Component.translatable("donutsplit.ah.invalid"));
                                        return 0;
                                    }
                                    player.connection.sendCommand("ah sell " + price.getAsLong());
                                    return 1;
                                }))));
    }
}
