package com.donutsplit;

import com.donutsplit.ah.QuickSellCommand;
import com.donutsplit.config.ModConfig;
import com.donutsplit.gui.AhScreen;
import com.donutsplit.gui.SplitConfigScreen;
import com.donutsplit.split.InventoryHooks;
import com.donutsplit.split.SplitManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DonutSplitClient implements ClientModInitializer {

    public static final String MOD_ID = "donutsplit";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static int lastSelected = -1;
    private static boolean pendingOpenAh = false;

    @Override
    public void onInitializeClient() {
        ModConfig.load();
        Keybinds.register();
        InventoryHooks.register();
        QuickSellCommand.register();
        ClientTickEvents.END_CLIENT_TICK.register(DonutSplitClient::onTick);
        LOGGER.info("DonutSplit loaded");
    }

    /** Used by the /quicksell command so the screen opens after the chat screen has closed. */
    public static void requestOpenAh() {
        pendingOpenAh = true;
    }

    private static void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.gameMode == null) {
            SplitManager.reset();
            lastSelected = -1;
            pendingOpenAh = false;
            return;
        }

        SplitManager.tick(mc);

        // Always drain every keybind so presses never pile up.
        boolean openGui = false;
        boolean split = false;
        boolean toggle = false;
        boolean ah = false;
        while (Keybinds.openGui.consumeClick()) {
            openGui = true;
        }
        while (Keybinds.split.consumeClick()) {
            split = true;
        }
        while (Keybinds.toggle.consumeClick()) {
            toggle = true;
        }
        while (Keybinds.ahSettings.consumeClick()) {
            ah = true;
        }

        ModConfig cfg = ModConfig.get();

        if (openGui && mc.screen == null) {
            mc.setScreen(new SplitConfigScreen(null));
        }
        if ((ah || pendingOpenAh) && mc.screen == null) {
            pendingOpenAh = false;
            mc.setScreen(new AhScreen(null));
        }
        if (toggle) {
            cfg.enabled = !cfg.enabled;
            ModConfig.save();
            mc.player.displayClientMessage(
                    Component.translatable(cfg.enabled ? "donutsplit.msg.toggle_on" : "donutsplit.msg.toggle_off"),
                    true);
        }
        if (split && cfg.enabled) {
            SplitManager.requestSelected(mc);
        }

        handleSelectionChange(mc, cfg);
    }

    /** Selecting a hotbar slot makes its configured amount the active one. */
    private static void handleSelectionChange(Minecraft mc, ModConfig cfg) {
        int selected = mc.player.getInventory().getSelectedSlot();
        if (selected == lastSelected) {
            return;
        }
        boolean first = lastSelected == -1;
        lastSelected = selected;
        if (first || !cfg.enabled) {
            return;
        }
        int amount = cfg.amountFor(selected);
        if (cfg.showSelectionHint) {
            mc.player.displayClientMessage(amount > 0
                    ? Component.translatable("donutsplit.msg.hint", amount)
                    : Component.translatable("donutsplit.msg.hint_off", selected + 1), true);
        }
        if (cfg.autoSplitOnSelect && amount > 0) {
            SplitManager.request(mc, 36 + selected, amount, true);
        }
    }
}
