package com.donutsplit.split;

import com.donutsplit.config.ModConfig;
import com.donutsplit.mixin.AbstractContainerScreenAccessor;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.world.inventory.Slot;
import org.lwjgl.glfw.GLFW;

/**
 * Mouse splitting inside the survival inventory screen:
 * Ctrl + Right-click (or Alt + Right-click, configurable) on a stack sets it to the
 * split amount of the currently selected hotbar slot. Every other click is untouched.
 */
public final class InventoryHooks {

    private InventoryHooks() {
    }

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof InventoryScreen) {
                ScreenMouseEvents.allowMouseClick(screen).register(InventoryHooks::onMouseClick);
            }
        });
    }

    /** @return false to cancel the click (we handled it), true to let vanilla continue. */
    private static boolean onMouseClick(Screen screen, MouseButtonEvent event) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.enabled || !cfg.mouseSplitEnabled || event.button() != GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
            return true;
        }
        int mask = cfg.mouseUseAlt ? GLFW.GLFW_MOD_ALT : GLFW.GLFW_MOD_CONTROL;
        if ((event.modifiers() & mask) == 0) {
            return true;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return true;
        }
        Slot hovered = ((AbstractContainerScreenAccessor) screen).donutsplit$getHoveredSlot();
        if (hovered == null || !hovered.hasItem()) {
            return true;
        }
        int amount = cfg.amountFor(mc.player.getInventory().getSelectedSlot());
        if (amount <= 0) {
            return true;
        }
        SplitManager.request(mc, hovered.index, amount, false);
        return false;
    }
}
