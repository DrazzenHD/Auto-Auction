package com.donutsplit.split;

import com.donutsplit.config.ModConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Splits stacks using ONLY ordinary vanilla inventory clicks sent through
 * MultiPlayerGameMode#handleInventoryMouseClick. The client never invents items:
 * the server performs every click and stays authoritative.
 *
 * Meaning of "split to N": the chosen stack ends up with exactly N items and the
 * remainder moves into the first free inventory slot. N = 64 (or the item's max
 * stack size) instead merges matching stacks together up to a full stack.
 *
 * Safety: each step is checked against the expected state before it is sent. If
 * anything is unexpected (lag correction, a container opened, ...) the task stops
 * and puts any item held on the cursor back into the inventory. Items are never dropped.
 */
public final class SplitManager {

    private static final int MAIN_START = 9;
    private static final int HOTBAR_START = 36;
    private static final int HOTBAR_END = 44;
    private static final int ACK_TIMEOUT_TICKS = 40;

    private static Task current;

    private SplitManager() {
    }

    public static boolean isBusy() {
        return current != null;
    }

    public static void reset() {
        current = null;
    }

    public static void tick(Minecraft mc) {
        if (current != null && current.tick(mc)) {
            current = null;
        }
    }

    /** Applies the selected hotbar slot's amount to the stack in that slot. */
    public static void requestSelected(Minecraft mc) {
        LocalPlayer player = mc.player;
        if (player == null) {
            return;
        }
        int sel = player.getInventory().getSelectedSlot();
        int amount = ModConfig.get().amountFor(sel);
        if (amount <= 0) {
            say(mc, "donutsplit.msg.slot_disabled", sel + 1);
            return;
        }
        request(mc, HOTBAR_START + sel, amount, false);
    }

    /**
     * @param slotId inventory-menu slot id (9-35 main inventory, 36-44 hotbar)
     * @param quiet  suppress "nothing to do" messages (used by auto-split)
     */
    public static void request(Minecraft mc, int slotId, int amount, boolean quiet) {
        LocalPlayer player = mc.player;
        if (current != null || player == null || mc.gameMode == null || player.isSpectator()) {
            return;
        }
        if (player.containerMenu != player.inventoryMenu) {
            if (!quiet) {
                say(mc, "donutsplit.msg.container_open");
            }
            return;
        }
        AbstractContainerMenu menu = player.inventoryMenu;
        if (!menu.getCarried().isEmpty()) {
            if (!quiet) {
                say(mc, "donutsplit.msg.cursor_busy");
            }
            return;
        }
        if (slotId < MAIN_START || slotId > HOTBAR_END) {
            if (!quiet) {
                say(mc, "donutsplit.msg.bad_slot");
            }
            return;
        }
        ItemStack stack = menu.getSlot(slotId).getItem();
        if (stack.isEmpty()) {
            if (!quiet) {
                say(mc, "donutsplit.msg.empty");
            }
            return;
        }

        ItemStack proto = stack.copyWithCount(1);
        int count = stack.getCount();
        int max = stack.getMaxStackSize();

        if (amount >= max) {
            // "64" mode: merge matching stacks up to a full stack.
            if (count >= max) {
                if (!quiet) {
                    say(mc, "donutsplit.msg.already_full");
                }
                return;
            }
            int total = 0;
            for (int i = MAIN_START; i <= HOTBAR_END; i++) {
                ItemStack other = menu.getSlot(i).getItem();
                if (!other.isEmpty() && ItemStack.isSameItemSameComponents(proto, other)) {
                    total += other.getCount();
                }
            }
            if (total <= count) {
                if (!quiet) {
                    say(mc, "donutsplit.msg.nothing_to_merge");
                }
                return;
            }
            current = buildMerge(proto, slotId, count, max);
            return;
        }

        if (count <= amount) {
            if (!quiet) {
                say(mc, "donutsplit.msg.too_small", count);
            }
            return;
        }

        int empty = findEmptySlot(menu, slotId);
        if (empty < 0) {
            if (!quiet) {
                say(mc, "donutsplit.msg.no_space");
            }
            return;
        }
        current = buildSplit(proto, slotId, empty, count, amount);
    }

    // ------------------------------------------------------------------ plans

    private record Click(int slot, int button, ClickType type, Predicate<int[]> pre) {
    }

    private static Task buildSplit(ItemStack proto, int slotS, int slotE, int total, int target) {
        List<Click> steps = new ArrayList<>();
        int[] st = {total, 0, 0}; // {count in S, count in E, count on cursor}
        int rest = total - target;

        if (target == total / 2) {
            // Right-click picks up the larger half; the smaller half (== target) stays.
            add(steps, st, slotS, 0, 1, ClickType.PICKUP);
            add(steps, st, slotE, 1, 0, ClickType.PICKUP);
        } else if (target <= rest) {
            // Pick everything up, drop `target` singles back, put the rest in E.
            add(steps, st, slotS, 0, 0, ClickType.PICKUP);
            for (int i = 0; i < target; i++) {
                add(steps, st, slotS, 0, 1, ClickType.PICKUP);
            }
            add(steps, st, slotE, 1, 0, ClickType.PICKUP);
        } else {
            // Pick everything up, drop `rest` singles into E, put the remainder back in S.
            add(steps, st, slotS, 0, 0, ClickType.PICKUP);
            for (int i = 0; i < rest; i++) {
                add(steps, st, slotE, 1, 1, ClickType.PICKUP);
            }
            add(steps, st, slotS, 0, 0, ClickType.PICKUP);
        }

        final int fs = st[0];
        final int fe = st[1];
        final int fc = st[2];
        return new Task(proto, slotS, slotE, steps,
                s -> s[0] == fs && s[1] == fe && s[2] == fc,
                "donutsplit.msg.split_done", target, rest);
    }

    private static Task buildMerge(ItemStack proto, int slotS, int count, int max) {
        List<Click> steps = new ArrayList<>();
        steps.add(new Click(slotS, 0, ClickType.PICKUP, s -> s[0] == count && s[2] == 0));
        steps.add(new Click(slotS, 0, ClickType.PICKUP_ALL, s -> s[0] == 0 && s[2] == count));
        steps.add(new Click(slotS, 0, ClickType.PICKUP, s -> s[0] == 0 && s[2] >= count && s[2] <= max));
        return new Task(proto, slotS, -1, steps,
                s -> s[0] >= count && s[2] == 0,
                "donutsplit.msg.merged", -1, 0);
    }

    private static void add(List<Click> steps, int[] st, int slot, int which, int button, ClickType type) {
        final int a = st[0];
        final int b = st[1];
        final int c = st[2];
        steps.add(new Click(slot, button, type, s -> s[0] == a && s[1] == b && s[2] == c));
        simulate(st, which, button);
    }

    /** Mirrors vanilla PICKUP click behaviour for slot S (which=0) or E (which=1). */
    private static void simulate(int[] st, int which, int button) {
        if (button == 0) {
            if (st[2] > 0) {
                st[which] += st[2];
                st[2] = 0;
            } else {
                st[2] = st[which];
                st[which] = 0;
            }
        } else if (st[2] > 0) {
            st[which] += 1;
            st[2] -= 1;
        } else {
            int take = (st[which] + 1) / 2;
            st[2] = take;
            st[which] -= take;
        }
    }

    private static int findEmptySlot(AbstractContainerMenu menu, int exclude) {
        for (int i = MAIN_START; i <= HOTBAR_END; i++) {
            if (i != exclude && menu.getSlot(i).getItem().isEmpty()) {
                return i;
            }
        }
        return -1;
    }

    private static void say(Minecraft mc, String key, Object... args) {
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.translatable(key, args), true);
        }
    }

    // ------------------------------------------------------------------- task

    private static final class Task {
        private final ItemStack proto;
        private final int slotS;
        private final int slotE;
        private final List<Click> steps;
        private final Predicate<int[]> finalCheck;
        private final String successKey;
        private final int successA;
        private final int successB;
        private int index;
        private int waited;

        Task(ItemStack proto, int slotS, int slotE, List<Click> steps, Predicate<int[]> finalCheck,
             String successKey, int successA, int successB) {
            this.proto = proto;
            this.slotS = slotS;
            this.slotE = slotE;
            this.steps = steps;
            this.finalCheck = finalCheck;
            this.successKey = successKey;
            this.successA = successA;
            this.successB = successB;
        }

        /** @return true when the task is finished (successfully or not). */
        boolean tick(Minecraft mc) {
            LocalPlayer player = mc.player;
            if (player == null || mc.gameMode == null || player.containerMenu != player.inventoryMenu) {
                restore(mc);
                return true;
            }
            AbstractContainerMenu menu = player.inventoryMenu;

            int budget = ModConfig.get().clicksPerTick;
            while (budget-- > 0 && index < steps.size()) {
                Click click = steps.get(index);
                if (!click.pre().test(state(menu))) {
                    restore(mc);
                    return true;
                }
                mc.gameMode.handleInventoryMouseClick(menu.containerId, click.slot(), click.button(),
                        click.type(), player);
                index++;
            }
            if (index < steps.size()) {
                return false;
            }

            // All clicks sent. Wait until the (server-confirmed) state matches the plan.
            if (finalCheck.test(state(menu))) {
                if (successA >= 0) {
                    say(mc, successKey, successA, successB);
                } else {
                    say(mc, successKey, menu.getSlot(slotS).getItem().getCount());
                }
                return true;
            }
            if (++waited > ACK_TIMEOUT_TICKS) {
                restore(mc);
                return true;
            }
            return false;
        }

        private int[] state(AbstractContainerMenu menu) {
            return new int[]{
                    count(menu.getSlot(slotS).getItem()),
                    slotE >= 0 ? count(menu.getSlot(slotE).getItem()) : 0,
                    count(menu.getCarried())
            };
        }

        private int count(ItemStack stack) {
            if (stack.isEmpty()) {
                return 0;
            }
            return ItemStack.isSameItemSameComponents(proto, stack) ? stack.getCount() : -1000;
        }

        /** Puts an item left on the cursor back into the inventory. Never drops anything. */
        private void restore(Minecraft mc) {
            LocalPlayer player = mc.player;
            if (player != null && mc.gameMode != null && player.containerMenu == player.inventoryMenu) {
                AbstractContainerMenu menu = player.inventoryMenu;
                ItemStack carried = menu.getCarried();
                if (!carried.isEmpty()) {
                    int target = findPlacement(menu, carried);
                    if (target >= 0) {
                        mc.gameMode.handleInventoryMouseClick(menu.containerId, target, 0, ClickType.PICKUP, player);
                    }
                }
            }
            say(mc, "donutsplit.msg.failed");
        }

        private int findPlacement(AbstractContainerMenu menu, ItemStack carried) {
            int[] preferred = {slotS, slotE};
            for (int slot : preferred) {
                if (slot >= 0 && fits(menu.getSlot(slot).getItem(), carried)) {
                    return slot;
                }
            }
            for (int i = MAIN_START; i <= HOTBAR_END; i++) {
                ItemStack in = menu.getSlot(i).getItem();
                if (!in.isEmpty() && fits(in, carried)) {
                    return i;
                }
            }
            for (int i = MAIN_START; i <= HOTBAR_END; i++) {
                if (menu.getSlot(i).getItem().isEmpty()) {
                    return i;
                }
            }
            return -1;
        }

        /** True if all of `carried` can be placed on `target` with a single left click. */
        private static boolean fits(ItemStack target, ItemStack carried) {
            if (target.isEmpty()) {
                return true;
            }
            return ItemStack.isSameItemSameComponents(target, carried)
                    && target.getCount() + carried.getCount() <= target.getMaxStackSize();
        }
    }
}
