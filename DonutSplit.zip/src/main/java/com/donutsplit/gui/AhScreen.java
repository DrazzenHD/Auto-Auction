package com.donutsplit.gui;

import com.donutsplit.ah.PriceParser;
import com.donutsplit.config.ModConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.OptionalLong;

/**
 * Optional /ah sell helper. Pressing "Sell" sends one normal "/ah sell <price>" command
 * for the item in your main hand - exactly what you would type yourself. Nothing is automated.
 */
public class AhScreen extends Screen {

    private final Screen parent;
    private EditBox priceBox;
    private final EditBox[] presetBoxes = new EditBox[4];
    private final Button[] presetButtons = new Button[4];
    private Button sellButton;
    private Button enableToggle;
    private Component status = Component.empty();

    public AhScreen(Screen parent) {
        super(Component.translatable("donutsplit.ah.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ModConfig cfg = ModConfig.get();
        int cx = this.width / 2;

        priceBox = new EditBox(this.font, cx - 100, 72, 200, 20, Component.translatable("donutsplit.ah.price"));
        priceBox.setMaxLength(24);
        priceBox.setValue(cfg.lastAhPrice);
        priceBox.setResponder(s -> updateSellState());
        addRenderableWidget(priceBox);

        int pw = 48;
        int gap = 4;
        int start = cx - (4 * pw + 3 * gap) / 2;
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            presetButtons[i] = addRenderableWidget(Button.builder(Component.literal(cfg.ahPresets[i]),
                            b -> priceBox.setValue(presetBoxes[idx].getValue()))
                    .bounds(start + i * (pw + gap), 98, pw, 20).build());

            presetBoxes[i] = new EditBox(this.font, start + i * (pw + gap), 138, pw, 18, Component.empty());
            presetBoxes[i].setMaxLength(10);
            presetBoxes[i].setValue(cfg.ahPresets[i]);
            presetBoxes[i].setResponder(s -> {
                ModConfig.get().ahPresets[idx] = s.trim();
                presetButtons[idx].setMessage(Component.literal(s.trim()));
            });
            addRenderableWidget(presetBoxes[i]);
        }

        sellButton = addRenderableWidget(Button.builder(Component.translatable("donutsplit.ah.sell"),
                b -> sell()).bounds(cx - 100, 166, 200, 20).build());

        enableToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            ModConfig c = ModConfig.get();
            c.ahEnabled = !c.ahEnabled;
            ModConfig.save();
            updateSellState();
        }).bounds(cx - 100, 192, 98, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .bounds(cx + 2, 192, 98, 20).build());

        updateSellState();
    }

    private ItemStack held() {
        LocalPlayer player = Minecraft.getInstance().player;
        return player != null ? player.getMainHandItem() : ItemStack.EMPTY;
    }

    private void updateSellState() {
        ModConfig cfg = ModConfig.get();
        boolean valid = PriceParser.parse(priceBox.getValue()).isPresent();
        sellButton.active = cfg.ahEnabled && !held().isEmpty() && valid;
        enableToggle.setMessage(Component.translatable("donutsplit.ah.enabled",
                Component.translatable(cfg.ahEnabled ? "options.on" : "options.off")
                        .withStyle(cfg.ahEnabled ? ChatFormatting.GREEN : ChatFormatting.RED)));
        if (!cfg.ahEnabled) {
            status = Component.translatable("donutsplit.ah.disabled").withStyle(ChatFormatting.RED);
        } else if (held().isEmpty()) {
            status = Component.translatable("donutsplit.ah.hold_item").withStyle(ChatFormatting.RED);
        } else if (!valid && !priceBox.getValue().isBlank()) {
            status = Component.translatable("donutsplit.ah.invalid").withStyle(ChatFormatting.RED);
        } else {
            status = Component.empty();
        }
    }

    private void sell() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        ModConfig cfg = ModConfig.get();
        if (player == null || !cfg.ahEnabled || held().isEmpty()) {
            return;
        }
        OptionalLong price = PriceParser.parse(priceBox.getValue());
        if (price.isEmpty()) {
            return;
        }
        cfg.lastAhPrice = priceBox.getValue().trim();
        ModConfig.save();
        player.connection.sendCommand("ah sell " + price.getAsLong());
        onClose();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        super.render(graphics, mouseX, mouseY, delta);
        int cx = this.width / 2;
        graphics.drawCenteredString(this.font, this.title, cx, 10, 0xFFFFFFFF);

        ItemStack stack = held();
        if (stack.isEmpty()) {
            graphics.drawCenteredString(this.font, Component.translatable("donutsplit.ah.hold_item"), cx, 38, 0xFFAAAAAA);
        } else {
            graphics.renderItem(stack, cx - 100, 30);
            graphics.drawString(this.font, Component.translatable("donutsplit.ah.holding",
                    stack.getCount(), stack.getHoverName()), cx - 78, 35, 0xFFFFFFFF);
        }

        graphics.drawString(this.font, Component.translatable("donutsplit.ah.price"), cx - 100, 60, 0xFFAAAAAA);
        graphics.drawString(this.font, Component.translatable("donutsplit.ah.shortcuts"), cx - 100, 88, 0xFFAAAAAA);
        graphics.drawString(this.font, Component.translatable("donutsplit.ah.edit_shortcuts"), cx - 100, 126, 0xFFAAAAAA);
        graphics.drawCenteredString(this.font, status, cx, 156, 0xFFFF5555);
    }

    @Override
    public void onClose() {
        ModConfig.save();
        this.minecraft.setScreen(parent);
    }
}
