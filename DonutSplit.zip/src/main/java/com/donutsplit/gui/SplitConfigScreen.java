package com.donutsplit.gui;

import com.donutsplit.config.ModConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** Hotbar split configuration. Every change is saved immediately. */
public class SplitConfigScreen extends Screen {

    private final Screen parent;
    private int selected;

    private final Button[] slotButtons = new Button[9];
    private final Button[] amountButtons = new Button[ModConfig.AMOUNTS.length];
    private Button slotToggle;
    private Button splitterToggle;
    private Button autoToggle;
    private Button mouseToggle;
    private Button modifierToggle;
    private Button hintToggle;
    private Button clicksButton;

    public SplitConfigScreen(Screen parent) {
        super(Component.translatable("donutsplit.config.title"));
        this.parent = parent;
        Minecraft mc = Minecraft.getInstance();
        this.selected = mc.player != null ? mc.player.getInventory().getSelectedSlot() : 0;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        // Row 1: the 9 hotbar slots
        int slotW = 32;
        int slotGap = 2;
        int startX = cx - (9 * slotW + 8 * slotGap) / 2;
        int y = 30;
        for (int i = 0; i < 9; i++) {
            final int idx = i;
            slotButtons[i] = addRenderableWidget(Button.builder(Component.empty(), b -> {
                selected = idx;
                refresh();
            }).bounds(startX + i * (slotW + slotGap), y, slotW, 20).build());
        }

        // Row 2: amount buttons for the selected slot
        int amtW = 40;
        int amtGap = 4;
        int amtStart = cx - (amountButtons.length * amtW + (amountButtons.length - 1) * amtGap) / 2;
        y = 68;
        for (int k = 0; k < amountButtons.length; k++) {
            final int amount = ModConfig.AMOUNTS[k];
            amountButtons[k] = addRenderableWidget(Button.builder(Component.empty(), b -> {
                ModConfig.get().slotAmounts[selected] = amount;
                ModConfig.get().slotEnabled[selected] = true;
                ModConfig.save();
                refresh();
            }).bounds(amtStart + k * (amtW + amtGap), y, amtW, 20).build());
        }

        int left = cx - 155;
        int right = cx + 5;
        int colW = 150;

        // Row 3: enable/disable selected slot + reset
        y = 94;
        slotToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            ModConfig cfg = ModConfig.get();
            cfg.slotEnabled[selected] = !cfg.slotEnabled[selected];
            ModConfig.save();
            refresh();
        }).bounds(left, y, colW, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("donutsplit.gui.reset"), b -> {
            ModConfig.get().resetSplitterDefaults();
            ModConfig.save();
            refresh();
        }).bounds(right, y, colW, 20).build());

        // Rows 4-6: options
        y = 124;
        splitterToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            ModConfig cfg = ModConfig.get();
            cfg.enabled = !cfg.enabled;
            ModConfig.save();
            refresh();
        }).bounds(left, y, colW, 20).build());
        autoToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            ModConfig cfg = ModConfig.get();
            cfg.autoSplitOnSelect = !cfg.autoSplitOnSelect;
            ModConfig.save();
            refresh();
        }).bounds(right, y, colW, 20).build());

        y = 148;
        mouseToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            ModConfig cfg = ModConfig.get();
            cfg.mouseSplitEnabled = !cfg.mouseSplitEnabled;
            ModConfig.save();
            refresh();
        }).bounds(left, y, colW, 20).build());
        modifierToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            ModConfig cfg = ModConfig.get();
            cfg.mouseUseAlt = !cfg.mouseUseAlt;
            ModConfig.save();
            refresh();
        }).bounds(right, y, colW, 20).build());

        y = 172;
        hintToggle = addRenderableWidget(Button.builder(Component.empty(), b -> {
            ModConfig cfg = ModConfig.get();
            cfg.showSelectionHint = !cfg.showSelectionHint;
            ModConfig.save();
            refresh();
        }).bounds(left, y, colW, 20).build());
        clicksButton = addRenderableWidget(Button.builder(Component.empty(), b -> {
            ModConfig cfg = ModConfig.get();
            cfg.clicksPerTick = cfg.clicksPerTick % 4 + 1;
            ModConfig.save();
            refresh();
        }).bounds(right, y, colW, 20).build());

        // Row 7: AH settings + Done
        y = 202;
        addRenderableWidget(Button.builder(Component.translatable("donutsplit.gui.ah_button"),
                b -> this.minecraft.setScreen(new AhScreen(this))).bounds(left, y, colW, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .bounds(right, y, colW, 20).build());

        refresh();
    }

    private static Component onOff(String key, boolean on) {
        return Component.translatable(key,
                Component.translatable(on ? "options.on" : "options.off")
                        .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED));
    }

    private void refresh() {
        ModConfig cfg = ModConfig.get();

        for (int i = 0; i < 9; i++) {
            String amount = cfg.slotEnabled[i] ? String.valueOf(cfg.slotAmounts[i]) : "--";
            MutableComponent label = Component.literal((i + 1) + ":" + amount);
            if (i == selected) {
                label = label.withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD);
            } else if (!cfg.slotEnabled[i]) {
                label = label.withStyle(ChatFormatting.RED);
            }
            slotButtons[i].setMessage(label);
        }

        for (int k = 0; k < amountButtons.length; k++) {
            int amount = ModConfig.AMOUNTS[k];
            MutableComponent label = Component.literal(String.valueOf(amount));
            if (cfg.slotEnabled[selected] && cfg.slotAmounts[selected] == amount) {
                label = label.withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD);
            }
            amountButtons[k].setMessage(label);
        }

        slotToggle.setMessage(onOff("donutsplit.gui.slot_toggle", cfg.slotEnabled[selected]));
        splitterToggle.setMessage(onOff("donutsplit.gui.splitter", cfg.enabled));
        autoToggle.setMessage(onOff("donutsplit.gui.auto", cfg.autoSplitOnSelect));
        mouseToggle.setMessage(onOff("donutsplit.gui.mouse", cfg.mouseSplitEnabled));
        modifierToggle.setMessage(Component.translatable("donutsplit.gui.modifier",
                Component.translatable(cfg.mouseUseAlt ? "donutsplit.gui.alt" : "donutsplit.gui.ctrl")));
        hintToggle.setMessage(onOff("donutsplit.gui.hint", cfg.showSelectionHint));
        clicksButton.setMessage(Component.translatable("donutsplit.gui.clicks", cfg.clicksPerTick));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        super.render(graphics, mouseX, mouseY, delta);
        int cx = this.width / 2;
        graphics.drawCenteredString(this.font, this.title, cx, 10, 0xFFFFFFFF);
        graphics.drawCenteredString(this.font, Component.translatable("donutsplit.gui.pick_slot"), cx, 20, 0xFFAAAAAA);

        Minecraft mc = Minecraft.getInstance();
        int active = mc.player != null ? mc.player.getInventory().getSelectedSlot() + 1 : selected + 1;
        graphics.drawCenteredString(this.font,
                Component.translatable("donutsplit.gui.editing", selected + 1, active), cx, 56, 0xFFFFFF55);
    }

    @Override
    public void onClose() {
        ModConfig.save();
        this.minecraft.setScreen(parent);
    }
}
