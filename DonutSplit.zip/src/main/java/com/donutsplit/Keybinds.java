package com.donutsplit;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/** Keybinds; all of them can be rebound in Options > Controls > Key Binds. */
public final class Keybinds {

    public static KeyMapping openGui;
    public static KeyMapping split;
    public static KeyMapping toggle;
    public static KeyMapping ahSettings;

    private Keybinds() {
    }

    public static void register() {
        KeyMapping.Category category =
                KeyMapping.Category.register(Identifier.fromNamespaceAndPath(DonutSplitClient.MOD_ID, "main"));
        openGui = reg("open_gui", GLFW.GLFW_KEY_K, category);
        split = reg("split", GLFW.GLFW_KEY_V, category);
        toggle = reg("toggle", GLFW.GLFW_KEY_J, category);
        ahSettings = reg("ah_settings", GLFW.GLFW_KEY_U, category);
    }

    private static KeyMapping reg(String id, int defaultKey, KeyMapping.Category category) {
        return KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key." + DonutSplitClient.MOD_ID + "." + id, InputConstants.Type.KEYSYM,
                        defaultKey, category));
    }
}
