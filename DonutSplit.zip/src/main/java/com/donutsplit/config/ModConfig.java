package com.donutsplit.config;

import com.donutsplit.DonutSplitClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Persistent configuration, stored as config/donutsplit.json. */
public final class ModConfig {

    /** Amounts offered by the GUI buttons. Any value 1..64 in the JSON file also works. */
    public static final int[] AMOUNTS = {64, 32, 16, 8, 4, 2, 1};

    private static final int[] DEFAULT_AMOUNTS = {64, 32, 16, 8, 4, 2, 1, 8, 4};
    private static final boolean[] DEFAULT_ENABLED = {true, true, true, true, true, true, true, false, false};
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // ---- splitter ----
    public boolean enabled = true;
    /** When true, selecting a hotbar slot immediately splits the stack in it to that slot's amount. */
    public boolean autoSplitOnSelect = false;
    public boolean showSelectionHint = true;
    public boolean mouseSplitEnabled = true;
    /** false = Ctrl+Right-click, true = Alt+Right-click in the inventory screen. */
    public boolean mouseUseAlt = false;
    /** Inventory clicks sent per client tick (1..4). 1 is the gentlest for servers. */
    public int clicksPerTick = 1;
    public int[] slotAmounts = DEFAULT_AMOUNTS.clone();
    public boolean[] slotEnabled = DEFAULT_ENABLED.clone();

    // ---- auction house helper (optional) ----
    public boolean ahEnabled = true;
    public String[] ahPresets = {"1k", "10k", "100k", "1m"};
    public String lastAhPrice = "";

    private static ModConfig instance = new ModConfig();

    public static ModConfig get() {
        return instance;
    }

    /** Split amount for a hotbar slot (0-8), or 0 if that slot is disabled. */
    public int amountFor(int hotbarSlot) {
        if (hotbarSlot < 0 || hotbarSlot > 8 || !slotEnabled[hotbarSlot]) {
            return 0;
        }
        return slotAmounts[hotbarSlot];
    }

    public void resetSplitterDefaults() {
        enabled = true;
        autoSplitOnSelect = false;
        showSelectionHint = true;
        mouseSplitEnabled = true;
        mouseUseAlt = false;
        clicksPerTick = 1;
        slotAmounts = DEFAULT_AMOUNTS.clone();
        slotEnabled = DEFAULT_ENABLED.clone();
    }

    private void sanitize() {
        slotAmounts = fit(slotAmounts, DEFAULT_AMOUNTS);
        for (int i = 0; i < slotAmounts.length; i++) {
            slotAmounts[i] = Math.max(1, Math.min(64, slotAmounts[i]));
        }
        if (slotEnabled == null || slotEnabled.length != 9) {
            boolean[] fixed = DEFAULT_ENABLED.clone();
            if (slotEnabled != null) {
                System.arraycopy(slotEnabled, 0, fixed, 0, Math.min(9, slotEnabled.length));
            }
            slotEnabled = fixed;
        }
        clicksPerTick = Math.max(1, Math.min(4, clicksPerTick));
        if (ahPresets == null || ahPresets.length != 4) {
            String[] fixed = {"1k", "10k", "100k", "1m"};
            if (ahPresets != null) {
                System.arraycopy(ahPresets, 0, fixed, 0, Math.min(4, ahPresets.length));
            }
            ahPresets = fixed;
        }
        for (int i = 0; i < ahPresets.length; i++) {
            if (ahPresets[i] == null) {
                ahPresets[i] = "";
            }
        }
        if (lastAhPrice == null) {
            lastAhPrice = "";
        }
    }

    private static int[] fit(int[] in, int[] defaults) {
        int[] out = defaults.clone();
        if (in != null) {
            System.arraycopy(in, 0, out, 0, Math.min(out.length, in.length));
        }
        return out;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("donutsplit.json");
    }

    public static void load() {
        Path p = path();
        ModConfig loaded = null;
        if (Files.exists(p)) {
            try (Reader reader = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                loaded = GSON.fromJson(reader, ModConfig.class);
            } catch (IOException | JsonParseException e) {
                DonutSplitClient.LOGGER.error("Could not read {}; using defaults (old file kept as .bad)", p, e);
                try {
                    Files.move(p, p.resolveSibling("donutsplit.json.bad"), StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException ignored) {
                    // best effort only
                }
            }
        }
        instance = loaded != null ? loaded : new ModConfig();
        instance.sanitize();
        save();
    }

    public static void save() {
        Path p = path();
        Path tmp = p.resolveSibling("donutsplit.json.tmp");
        try {
            Files.createDirectories(p.getParent());
            try (Writer writer = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                GSON.toJson(instance, writer);
            }
            Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            DonutSplitClient.LOGGER.error("Could not save {}", p, e);
        }
    }
}
