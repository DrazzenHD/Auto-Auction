# DonutSplit (Fabric, Minecraft Java 1.21.11)

Client-side mod: configurable **hotbar item splitter** + optional **/ah sell quick-sell helper**.
No server-side install is needed, so it works in single-player and on servers.

> **Build status:** the source has NOT been compiled yet. The sandbox it was written in could not
> reach Fabric's Maven servers, so no `.jar` exists. Follow "Build the jar" below; if the compiler
> reports an error, send me the log and I'll fix it.

## How the splitter works

Each hotbar slot (1-9) has its own split amount (64/32/16/8/4/2/1) and can be enabled/disabled.
Selecting a hotbar slot makes its amount the *active* amount (shown on the action bar).

"Split to N" means: the chosen stack ends up with exactly **N** items and the remainder moves into
the first free inventory slot. Amount **64** merges matching stacks together up to a full stack.

| Action | Result |
|---|---|
| **V** (Split Held Stack) | Applies the selected slot's amount to the stack in your hand |
| **Ctrl + Right-click** a stack in the inventory screen (Alt optional) | Applies the selected slot's amount to that stack |
| Auto-split on select (GUI toggle, **off** by default) | Splits the stack automatically when you switch to that slot |
| **K** | Open the splitter GUI |
| **J** | Enable / disable the splitter |
| **U** | Open Auction House settings / quick-sell |

All keys are rebindable in Options > Controls > Key Binds > DonutSplit.

Safety: the mod only sends normal vanilla inventory clicks (one per tick by default). Every step is
verified first; if anything is unexpected (lag correction, container opened) it stops and puts any
cursor item back into the inventory. It never drops or creates items.

## Auction House helper (optional)

`U` or `/quicksell` opens a screen showing the held item, a price box (accepts `2500`, `10k`, `2.5m`),
four editable price shortcuts and a Sell button. Sell sends exactly one normal `/ah sell <price>`
command, the same as typing it. `/quicksell 10k` does the same without the screen. Turn the whole
feature off in that screen; it never touches the splitter.

## Build the jar

You need JDK 21. Choose one:

**A. GitHub Actions (easiest, works from a phone)**
1. Create a GitHub repo and upload this folder.
2. Open the *Actions* tab > *build* > run it. Download the `donutsplit-jar` artifact.

**B. Locally**
```
gradle build          # Gradle 8.14+; or run `gradle wrapper` once and use ./gradlew build
```
The jar is `build/libs/donutsplit-1.0.0.jar` (ignore the `-sources` jar).

If dependencies do not resolve, open https://fabricmc.net/develop/ , pick 1.21.11 and copy the
current `loader_version`, `loom_version` and `fabric_version` into `gradle.properties`.

## Install

1. Install Fabric Loader for 1.21.11 and the matching **Fabric API** into your `mods` folder.
2. Put `donutsplit-1.0.0.jar` into the same `mods` folder.
   (Zalith Launcher: add the files to the Fabric instance's `mods` folder.)
3. Launch, then press **K**.

## Test plan (singleplayer first)

1. New creative/survival world. Put 64 of an item in slot 1 and select slot 3 (16): press **V** — slot 3's stack becomes 16 and the other 48 go to a free slot.
2. Check counts add up exactly after each split (e.g. 64 -> 16 + 48; 37 -> 16 + 21).
3. Inventory screen: Ctrl + Right-click a stack — it is set to the selected slot's amount. Normal clicks, shift-click, drag must behave as vanilla.
4. Set a slot to Disabled: V and Ctrl+Right-click do nothing for that slot.
5. Quit and relaunch: the configuration is kept (`config/donutsplit.json`). Try *Reset to defaults*.
6. Full inventory: you should see "No free inventory slot" and nothing changes.

## Testing on DonutSMP

- Test in singleplayer first; only then join the server.
- Keep **Clicks per tick = 1** and leave **Auto-split on select** off. Servers may treat many rapid
  inventory clicks as suspicious; this mod does not try to hide or bypass anything, so follow
  the server's rules and stop using a feature if you are warned.
- Stand somewhere safe, split a small stack, and confirm the counts add up and nothing rubber-bands.
- AH helper: hold a cheap item, open the screen with **U**, enter a price, press Sell, and check the
  server's own confirmation message. Check the server rules before using it for large sales.

## Project layout

```
build.gradle, settings.gradle, gradle.properties
.github/workflows/build.yml
src/main/resources/{fabric.mod.json, donutsplit.mixins.json, assets/donutsplit/lang/en_us.json}
src/main/java/com/donutsplit/
  DonutSplitClient.java, Keybinds.java
  config/ModConfig.java
  split/{SplitManager, InventoryHooks}.java
  gui/{SplitConfigScreen, AhScreen}.java
  ah/{PriceParser, QuickSellCommand}.java
  mixin/AbstractContainerScreenAccessor.java
```
